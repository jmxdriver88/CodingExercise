namespace CodingExercise.Models
{
    /// <summary>
    /// The view model for the error page.
    /// </summary>
    public class ErrorViewModel
    {
        /// <summary>
        /// Gets or sets the page request id.
        /// </summary>
        public string RequestId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether or the request id can be displayed.
        /// </summary>
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
