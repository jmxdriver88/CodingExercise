﻿using CodingExercise.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace CodingExercise.Models
{
    /// <summary>
    /// Class containing several presentations for the user if they have none.
    /// </summary>
    public static class SeedData
    {
        /// <summary>
        /// Places the seed presentations in the database.
        /// </summary>
        /// <param name="serviceProvider">An reference to the <see cref="IServiceProvider"/> interface.</param>
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new PresentationContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<PresentationContext>>()))
            {
                // If any presentations exist, the database is already seeded.
                if (context.Presentation.Any())
                {
                    return;
                }

                context.Presentation.AddRange(
                    new Presentation
                    {
                        Title = "Using Words and Letters to Make Books and Such",
                        PresenterName = "Mark Twain",
                        Duration = 20
                    },
                    new Presentation
                    {
                        Title = "The Meaning of Life",
                        PresenterName = "Arthur Dent",
                        Duration = 42
                    },
                    new Presentation
                    {
                        Title = "Asking: What to Ask For and What Not to Ask For",
                        PresenterName = "Jonathan F. Kennedy",
                        Duration = 1
                    },
                    new Presentation
                    {
                        Title = "Is It Friday Yet?",
                        PresenterName = "Rebecca Black",
                        Duration = 4
                    },
                    new Presentation
                    {
                        Title = "How to Make Your Bread and Eat It Too",
                        PresenterName = "The Little Red Hen",
                        Duration = 45
                    },
                    new Presentation
                    {
                        Title = "Studies In Correlations Between High IQs and Messy Desks",
                        PresenterName = "Albert Einstein",
                        Duration = 60
                    },
                    new Presentation
                    {
                        Title = "The Dawn of Social Media",
                        PresenterName = "Mark Zuckerburg",
                        Duration = 30
                    },
                    new Presentation
                    {
                        Title = "How to Ski Really, Really Fast",
                        PresenterName = "Mikaela Shiffrin",
                        Duration = 15
                    },
                    new Presentation
                    {
                        Title = "I'll Be Bach: My New Passion for Music Composition",
                        PresenterName = "Arnold Schwarzenegger",
                        Duration = 60
                    }
                );
                context.SaveChanges();
            }
        }
    }
}