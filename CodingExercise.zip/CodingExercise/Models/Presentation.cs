﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CodingExercise.Models
{
    /// <summary>
    /// The class mapping the presentation entity.
    /// </summary>
    public class Presentation
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public Presentation()
        {
            Duration = 30;
        }

        /// <summary>
        /// Gets or sets the unique identifier of the presentation.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the title of the presentation.
        /// </summary>
        [Required, StringLength(99, MinimumLength = 2), Display(Name = "Title"),
            RegularExpression("^\\S.*?\\S$", ErrorMessage = "Please trim whitespace.")]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the name of the presenter.
        /// </summary>
        [Required, StringLength(49, MinimumLength = 2), Display(Name = "Presenter"),
            RegularExpression("^\\S.*?\\S$", ErrorMessage = "Please trim whitespace.")]
        public string PresenterName { get; set; }

        /// <summary>
        /// Gets or sets the duration of the presentation in minutes.
        /// </summary>
        [Required, Range(1, 60), Display(Name = "Duration")]
        public int Duration { get; set; }
   }
}
