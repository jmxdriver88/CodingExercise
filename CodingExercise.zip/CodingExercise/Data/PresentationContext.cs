﻿using CodingExercise.Models;
using Microsoft.EntityFrameworkCore;

namespace CodingExercise.Data
{
    public class PresentationContext : DbContext
    {
        public PresentationContext (DbContextOptions<PresentationContext> options)
            : base(options)
        {
        }

        public DbSet<Presentation> Presentation { get; set; }
    }
}
