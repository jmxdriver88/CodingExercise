﻿using CodingExercise.Data;
using CodingExercise.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace CodingExercise.Controllers
{
    /// <summary>
    /// Class containing actions for the Presentations controller.
    /// </summary>
    public class PresentationsController : Controller
    {
        private readonly PresentationContext _context;

        /// <summary>
        /// The default constructor.
        /// </summary>
        /// <param name="context">The database context for the Presentations table.</param>
        public PresentationsController(PresentationContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Creates the main page containing the presentations table.
        /// </summary>
        /// <returns>An action result containing the presentations table data.</returns>
        // GET: Presentations
        public async Task<IActionResult> Index()
        {
            // Sort the presentations alphabetically by title.
            return View(await _context.Presentation.OrderBy(x => x.Title).ToListAsync());
        }

        /// <summary>
        /// Creates a page to display the details of a particular presentation.
        /// </summary>
        /// <returns>An action result containing the presentation detail data.</returns>
        // GET: Presentations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentation = await _context.Presentation
                .FirstOrDefaultAsync(x => x.Id == id);

            if (presentation == null)
            {
                return NotFound();
            }

            return View(presentation);
        }

        /// <summary>
        /// Creates a page to create a new presentation.
        /// </summary>
        /// <returns>An action result containing the create page data.</returns>
        // GET: Presentations/Create
        [Authorize]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Creates a new presentation in the database.
        /// </summary>
        /// <returns>A redirect to the presentation page if successful.</returns>
        // POST: Presentations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Create([Bind("Id,Title,PresenterName,Duration")]
                Presentation presentation)
        {
            if (ModelState.IsValid)
            {
                _context.Add(presentation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(presentation);
        }

        /// <summary>
        /// Creates a page to edit a presentation.
        /// </summary>
        /// <returns>An action result containing the edit page data.</returns>
        // GET: Presentations/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentation = await _context.Presentation.FindAsync(id);

            if (presentation == null)
            {
                return NotFound();
            }

            return View(presentation);
        }

        /// <summary>
        /// Edits a presentation in the database.
        /// </summary>
        /// <returns>A redirect to the presentation page if successful.</returns>
        // POST: Presentations/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,PresenterName,Duration")]
                Presentation presentation)
        {
            if (id != presentation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(presentation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PresentationExists(presentation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(presentation);
        }

        /// <summary>
        /// Creates a page to delete a presentation.
        /// </summary>
        /// <returns>An action result containing the delete page data.</returns>
        // GET: Presentations/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentation = await _context.Presentation
                .FirstOrDefaultAsync(m => m.Id == id);

            if (presentation == null)
            {
                return NotFound();
            }

            return View(presentation);
        }

        /// <summary>
        /// Deletes a presentation in the database.
        /// </summary>
        /// <returns>A redirect to the presentation page.</returns>
        // POST: Presentations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var presentation = await _context.Presentation.FindAsync(id);
            _context.Presentation.Remove(presentation);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Determines if a presentation with a given id exists in the database.
        /// </summary>
        /// <param name="id">The id of the presentation.</param>
        /// <returns>True if an entity exists, false if not.</returns>
        private bool PresentationExists(int id)
        {
            return _context.Presentation.Any(e => e.Id == id);
        }
    }
}
