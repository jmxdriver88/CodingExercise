﻿using CodingExercise.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace CodingExercise.Controllers
{
    /// <summary>
    /// Class containing actions for the Home controller.
    /// </summary>
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        /// <summary>
        /// The default constructor.
        /// </summary>
        /// <param name="logger">An instance of the <see cref="ILogger{HomeController}"/> interface.</param>
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Creates the home page view.
        /// </summary>
        /// <returns>An action result containing home page data.</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Create an error page view.
        /// </summary>
        /// <returns>An action result containing error page data.</returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
